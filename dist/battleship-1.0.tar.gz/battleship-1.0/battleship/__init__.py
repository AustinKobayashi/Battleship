import battleship 

def main():
	battleship.start_game()
